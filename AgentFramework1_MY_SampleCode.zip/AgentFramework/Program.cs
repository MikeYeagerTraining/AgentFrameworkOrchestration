﻿using Azure.AI.OpenAI;
using Microsoft.Agents.AI;
using Microsoft.Extensions.AI;
using OpenAI.Responses;
using OpenAI.Chat;
using System.ClientModel;
using System.Configuration;

namespace AgentFramework
{
    internal class Program
    {
        private static string _azureOpenAiEndpoint; //e.g. https://codelegacy.openai.azure.com/
        private static string _azureOpenAiApiKey;
        private static string _chatDeployment = "gpt-4o";
        private static string _responseDeployment = "o4-mini";

        static async Task Main(string[] args)
        {
            _azureOpenAiEndpoint = ConfigurationManager.AppSettings["azureopenaiendpoint"]; //Azure OpenAI endpoint
            _azureOpenAiApiKey = ConfigurationManager.AppSettings["azureopenaiapiKey"];

            await OpenAIChat();
            //await IChatClientChat();
            //await AIAgentChat();
            //await OpenAIAgentChatWithTools();
            //await OpenAIAgentChatWithToolsAndMemory();
            ////await OllamaAIAgentChatWithToolsAndMemory();
            //await StructuredOutput();
            //await BackGroundResponseLongRunning();
            //await SimpleMultiAgentWorkflow();
        }

        private static async Task OpenAIChat()
        {
            ChatClient aOaiClient = new AzureOpenAIClient(
                new Uri(_azureOpenAiEndpoint), 
                new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment);

            var result = aOaiClient.CompleteChat(
                "What is the capital of France?");

            foreach (var content in result.Value.Content)
                Console.WriteLine(content.Text);
        }

        private static async Task IChatClientChat()
        {
            IChatClient chatClient = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsIChatClient();
            var result = await chatClient.GetResponseAsync(
                "What is the capital of France?");

            Console.WriteLine(result);

            await foreach (var content in chatClient.GetStreamingResponseAsync("What is the capital of France?"))
                Console.Write(content);
        }

        private static async Task AIAgentChat()
        {
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsIChatClient()
                .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.", 
                            name: "MyAgent");

            Console.WriteLine(await agent.RunAsync("What is the capital of France?"));

            await foreach (var response in agent.RunStreamingAsync("Explain how to tie shoelaces"))
                Console.Write(response);
        }

        private static async Task OpenAIAgentChatWithTools()
        {
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.", 
                            tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)], 
                            name: "MyAgentWithTools");

            Console.WriteLine(await agent.RunAsync("I'm in Taos, NM. Should I take an umbrella today?"));
        }

        private static async Task OpenAIAgentChatWithToolsAndMemory()
        {
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                            tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                            name: "MyAgentWithToolsAndMemory");

            AgentSession session = await agent.CreateSessionAsync();

            Console.WriteLine(await agent.RunAsync("I'm in Taos, NM.", session));
            Console.WriteLine(await agent.RunAsync("Should I take an umberlla today?", session));
        }

        //Currently broken with Microsoft.Agents.AI.OpenAI release candiates 3 and 4.
        //OllamaSharp needs to update their package (currently 5.4.24) to be compatible with the breaking changes in the new releases.
        //private static async Task OllamaAIAgentChatWithToolsAndMemory()
        //{
        //    AIAgent agent = new OllamaSharp.OllamaApiClient("http://localhost:11434", "llama3.1:8b")
        //        .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
        //                    name: "OllamaAgentWithToolsAndMemory");

        //    AgentSession session = await agent.CreateSessionAsync();

        //    Console.WriteLine(await agent.RunAsync("I'm in Taos, NM.", session));
        //    Console.WriteLine(await agent.RunAsync("Should I take an umberlla today?", session));
        //}

        private static async Task StructuredOutput()
        {
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                            name: "MyAgentWithStructuredOutput");

            AgentResponse<PersonInfo> response = 
                await agent.RunAsync<PersonInfo>("Please provide information about John Smith, who is a 35-year-old software engineer.");

            Console.WriteLine($"Name: {response.Result.Name}, Age: {response.Result.Age}, Occupation: {response.Result.Occupation}");
        }
        public class PersonInfo
        {
            public string? Name { get; set; }
            public int? Age { get; set; }
            public string? Occupation { get; set; }
        }

        private static async Task BackGroundResponseLongRunning()
        {
            //Deployed o4-mini model which supports Responses
            //https://learn.microsoft.com/en-us/azure/foundry/foundry-models/concepts/models-sold-directly-by-azure?tabs=global-standard-aoai%2Cglobal-standard&pivots=azure-openai#gpt-4o-and-gpt-4-turbo
            //Updated Azure.AI.OpenAI package to 2.x beta to use this feeature.
#pragma warning disable OPENAI001 // Type is for evaluation purposes only
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetResponsesClient(_responseDeployment)
                .AsAIAgent(instructions: "You are a friendly assistant.",
                            name: "MyAgentBackgroundResponse");

            AgentRunOptions options = new() { AllowBackgroundResponses = true };

            AgentSession session = await agent.CreateSessionAsync();

            AgentResponse response = await agent.RunAsync("Write a very long novel about otters in space.", session, options);

            // Continue to poll until the final response is received
            // In a reall application, pass this off to a background worker for example, instead of blocking the main thread with polling.
#pragma warning disable MEAI001 // Type is for evaluation purposes only
            while (response.ContinuationToken is not null)
            {
                Console.WriteLine("Waiting for final response...");
                // Wait before polling again.
                await Task.Delay(TimeSpan.FromSeconds(1));

                options.ContinuationToken = response.ContinuationToken;
                response = await agent.RunAsync(session, options);
            }

            Console.WriteLine(response.Text);
        }

        private static async Task SimpleMultiAgentWorkflow()
        {
            AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
                .GetChatClient(_chatDeployment)
                .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                            tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                            name: "MyAgentWithToolsAndMemory");

            AgentSession session = await agent.CreateSessionAsync();

            Console.WriteLine(await agent.RunAsync("I'm in Taos, NM.", session));
            Console.WriteLine(await agent.RunAsync("Should I take an umberlla today?", session));
        }
    }
}
