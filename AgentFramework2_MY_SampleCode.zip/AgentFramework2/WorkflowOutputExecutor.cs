﻿using Microsoft.Agents.AI.Workflows;
using Microsoft.Extensions.AI;

namespace AgentFramework2;

internal sealed partial class OutputExecutor() : Executor("OutputExecutor")
{
    protected override ProtocolBuilder ConfigureProtocol(ProtocolBuilder protocolBuilder)
    {
        return protocolBuilder
            .SendsMessage<List<ChatMessage>>()
            .SendsMessage<TurnToken>()
            .ConfigureRoutes(routes =>
            {
                routes.AddHandler<List<ChatMessage>>(HandleAsync);
            });
    }

    [MessageHandler]
    private async ValueTask HandleAsync(List<ChatMessage> messages, IWorkflowContext context, CancellationToken cancellationToken = default)
    {
        // Send the chat message to the next agent executor
        await context.SendMessageAsync(messages, cancellationToken: cancellationToken);

        // Send a turn token to signal the agent to process the accumulated messages
        await context.SendMessageAsync(new TurnToken(emitEvents: true), cancellationToken: cancellationToken);
    }
}

