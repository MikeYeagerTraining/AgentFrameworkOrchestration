﻿using Azure;
using Azure.AI.OpenAI;
using Microsoft.Agents.AI;
using Microsoft.Agents.AI.Compaction;
using Microsoft.Agents.AI.Workflows;
using Microsoft.Agents.AI.Workflows.Specialized.Magentic;
using Microsoft.Extensions.AI;
using OpenAI.Chat;
using OpenAI.Responses;
using System.ClientModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Runtime.CompilerServices;
using ChatMessage = Microsoft.Extensions.AI.ChatMessage;

namespace AgentFramework2;

internal class Program
{
    private static string _azureOpenAiEndpoint; //e.g. https://codelegacy.openai.azure.com/
    private static string _azureOpenAiApiKey;
    private static string _chatDeployment = "gpt-4o";

    static async Task Main(string[] args)
    {
        _azureOpenAiEndpoint = ConfigurationManager.AppSettings["azureopenaiendpoint"];
        _azureOpenAiApiKey = ConfigurationManager.AppSettings["azureopenaiapiKey"];

        await OpenAIAgentChatWithToolsAndMemory();
        //await SequentialWorkflow();
        //await ConcurrentWorkflow();
        //await HandoffWorkflow();
        ////await GroupChatWorkflow(); //under construction
        ////await MagenticWorkflow();  //under construction
        //await ExecutorsAndEdges();
    }

    private static async Task OpenAIAgentChatWithToolsAndMemory()
    {
        AIAgent agent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                        tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                        name: "MyAgentWithToolsAndMemory");

        AgentSession session = await agent.CreateSessionAsync();

        Console.WriteLine(await agent.RunAsync("I'm in Taos, NM.", session));
        Console.WriteLine(await agent.RunAsync("Should I take an umberlla today?", session));
    }

    //Orchestration are canned workflows that allow you to orchestrate multiple agents in a single conversation,
    //and define how messages should be passed between them.

    private static async Task SequentialWorkflow()
    {
        //Create your agents as you normally would. You can mix and match providers and models.
        AIAgent agent1 = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                        tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                        name: "MyAgentWithTools");

        AIAgent agent2 = new OllamaSharp.OllamaApiClient("http://localhost:11434", "llama3.1:8b")
            .AsAIAgent(instructions: $"You are a translation assistant who only responds in Spanish.",
                       name: "SpanishTranslator");

        //Next, set up the sequential workflow with the agents.
        var workflow = AgentWorkflowBuilder.BuildSequential(agent1, agent2);

        //Run the workflow
        var messages = new List<ChatMessage> 
        { 
            new(ChatRole.User, "I'm in Taos, NM."), 
            new(ChatRole.User, "Should I take an umberlla today?") 
        };
        await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, messages);
        await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

        //Show data from events as they stream in from the workflow execution.
        string? lastExecutorId = null;
        List<ChatMessage> result = [];
        await foreach (WorkflowEvent evt in run.WatchStreamAsync())
        {
            if (evt is AgentResponseUpdateEvent e)
            {
                if (e.ExecutorId != lastExecutorId)
                {
                    lastExecutorId = e.ExecutorId;
                    Console.WriteLine();
                    Console.Write($"{e.ExecutorId}: ");
                }

                Console.Write(e.Update.Text);
            }
            else if (evt is WorkflowOutputEvent outputEvt)
            {
                result = outputEvt.As<List<ChatMessage>>()!;
            }
        }
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine("END OF EXECUTION STREAM, BEGINNING OF RESULT");
        foreach (var message in result)
            Console.WriteLine($"{message.Role}: {message.Text}");
    }

    private static async Task ConcurrentWorkflow()
    {
        AIAgent agent1 = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                        tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                        name: "MyAgentWithTools");

        AIAgent agent2 = new OllamaSharp.OllamaApiClient("http://localhost:11434", "llama3.1:8b")
            .AsAIAgent(instructions: $"You are an assistant that detects the user's language. Make no attempt to answer the question. Only return the language used.",
                       name: "LanguageDetector");

        var workflow = AgentWorkflowBuilder.BuildConcurrent([agent1, agent2]);

        var messages = new List<ChatMessage>
        {
            new(ChatRole.User, "I'm in Taos, NM."),
            new(ChatRole.User, "Should I take an umberlla today?")
        };
        await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, messages);
        await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

        List<ChatMessage> result = [];
        await foreach (WorkflowEvent evt in run.WatchStreamAsync())
        {
            if (evt is AgentResponseUpdateEvent e)
            { 
                if (!string.IsNullOrEmpty(e.Update.Text))
                    Console.WriteLine($"{e.ExecutorId}: {e.Update.Text}");
            }
            else if (evt is WorkflowOutputEvent outputEvt)
            {
                result = outputEvt.As<List<ChatMessage>>()!;
            }
        }
        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine("END OF EXECUTION STREAM, BEGINNING OF RESULT");
        foreach (var message in result)
            Console.WriteLine($"{message.Role}: {message.Text}");
    }

    private static async Task HandoffWorkflow()
    {
        AIAgent agent1 = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief. Only respond to questions about the weather",
                        tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                        name: "MyAgentWithToolsAndMemory");

        AIAgent agent2 = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: $"You are a translation assistant who only responds in Spanish. Only respond if text needs to be translated to Spanish",
                       name: "SpanishTranslator");

        //Create the handoff agent which will manage the handoff between the agents.
        //This is a special type of agent that has the ability to send messages to other agents in the workflow,
        //and decide when to do so based on the specified rules.
        AIAgent handoffAgent = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "The user will ask you a question. If it's about the weather, handoff to MyAgentWithToolsAndMemory. If it's about translation or in Spanish, handoff to SpanishTranslator. ALWAYS handoff to another agent, don't answer the user's question directly.",
                       name: "HandoffAgent");

#pragma warning disable MAAIW001 // Type is for evaluation purposes only
        var workflow = AgentWorkflowBuilder.CreateHandoffBuilderWith(handoffAgent)
            .WithHandoffs(handoffAgent, [agent1, agent2])
            .WithHandoffs([agent1, agent2], handoffAgent)
            .Build();

        //Run the workflow as part of a multi-turn conversation,
        //and send messages to it in real-time as the user inputs them.
        List<ChatMessage> messages = new();
        while (true)
        {
            Console.WriteLine();
            Console.Write("Q: ");
            string? userInput = Console.ReadLine();
            if (string.IsNullOrEmpty(userInput)) break;

            messages.Add(new(ChatRole.User, userInput));

            // Execute workflow and process events
            await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, messages);
            await run.TrySendMessageAsync(new TurnToken(emitEvents: true));

            string? lastExecutorId = null;
            List<ChatMessage> newMessages = new();
            await foreach (WorkflowEvent evt in run.WatchStreamAsync())
            {
                if (evt is AgentResponseUpdateEvent e)
                {
                    if (e.ExecutorId != lastExecutorId)
                    {
                        lastExecutorId = e.ExecutorId;
                        Console.WriteLine($"AgentResponseUpdate event fired: {e.ExecutorId}");
                    }

                    Console.Write(e.Update.Text);
                }
                else if (evt is WorkflowOutputEvent outputEvt)
                {
                    newMessages = outputEvt.As<List<ChatMessage>>()!;
                }
            }

            // Add new messages to conversation history
            messages.AddRange(newMessages.Skip(messages.Count));
        }
    }

    private static async Task GroupChatWorkflow()
    {
        //Under construction
        return;
    }

    private static async Task MagenticWorkflow()
    {
        //Under construction
        return;
    }

    //Custom Workflows require you to define your Executors, Edges and Contracts,
    //giving you full control over the flow of the conversation and how agents
    //interact with each other, but also require more work to set up.
    private static async Task ExecutorsAndEdges()
    {
        AIAgent agent1 = new AzureOpenAIClient(new Uri(_azureOpenAiEndpoint), new ApiKeyCredential(_azureOpenAiApiKey))
            .GetChatClient(_chatDeployment)
            .AsAIAgent(instructions: "You are a friendly assistant. Keep your answers brief.",
                        tools: [AIFunctionFactory.Create(WeatherTool.GetWeather)],
                        name: "MyAgentWithToolsAndMemory");

        //custom logic component
        var customExecutor = new OutputExecutor();

        AIAgent agent2 = new OllamaSharp.OllamaApiClient("http://localhost:11434", "llama3.1:8b")
            .AsAIAgent(instructions: $"You are a translation assistant who only responds in Spanish. Be brief",
                       name: "SpanishTranslator");

        //Simple, sequential workflow using direct edges
        var workflow = new WorkflowBuilder(agent1)
            .AddEdge(agent1, customExecutor)
            .AddEdge(customExecutor, agent2)
            .WithOutputFrom(customExecutor)
            .Build();

        var inputMessage = "I'm in Taos, NM. Should I take an umberlla today?";

        // Streaming execution — get events as they happen
        await using StreamingRun run = await InProcessExecution.RunStreamingAsync(workflow, inputMessage);
        // Must send the turn token to trigger the agents.
        // The agents are wrapped as executors. When they receive messages,
        // they will cache the messages and only start processing when they receive a TurnToken.
        await run.TrySendMessageAsync(new TurnToken(emitEvents: true));
        //Show data from events as they stream in from the workflow execution.
        string? lastExecutorId = null;
        await foreach (WorkflowEvent evt in run.WatchStreamAsync())
        {
            if (evt is AgentResponseUpdateEvent e)
            {
                if (e.ExecutorId != lastExecutorId)
                {
                    lastExecutorId = e.ExecutorId;
                    Console.WriteLine();
                    Console.Write($"{e.ExecutorId}: ");
                }

                Console.Write(e.Update.Text);
            }
            else if (evt is WorkflowOutputEvent outputEvt)
            {
                Console.WriteLine();
                Console.WriteLine("Workflow output received.");
            }
            else if (evt is ExecutorCompletedEvent completedEvt)
            {
                Console.WriteLine();
                Console.WriteLine($"Executor {completedEvt.ExecutorId} completed.");
            }
            else if (evt is ExecutorFailedEvent failedEvt)
            {
                Console.WriteLine();
                Console.WriteLine($"Executor {failedEvt.ExecutorId} failed with error: {failedEvt}");
                break;
            }
            else if (evt is WorkflowErrorEvent workflowError)
            {
                Console.WriteLine();
                Console.WriteLine($"Workflow failed with error: {workflowError}");
                break;
            }
            else if (evt is WorkflowWarningEvent workflowWarning) 
            {
                Console.WriteLine();
                Console.WriteLine($"Workflow emitted a warning: {workflowWarning}");
            }
        }
        Console.WriteLine();
    }
}
